//=================================================  HEADER SECTION
#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>
#include <conio.h>
#include <stdlib.h>
#include<string.h>
//================================================= DEFINING STANDARD NAMESPACE 
using namespace std;

//================================================= CLASSES SECTION

class Admin
{

private:
	string ad_name;				// ----> admin names
	string ad_pw;				// ----> admin passwords
	string adm_name;									// ----> strings to hold input credentials 
	string adm_pw;
	string try_top;
	ifstream admin;
	bool login;
	bool log;
public:
	bool isLogin()											// ----> Function for authenticating the admin login through saved credentials in a file.
	{
		system("cls");
		Admin data[3];										// ----> Structure Array for storing the read data from the file				
		admin.open("Admin_logs.txt");						// ----> Opening the file for reading
		for (int i = 0; i < 3; i++)
		{
			admin >> data[i].ad_name;
			admin >> data[i].ad_pw;

		}

		login = false;
		cin.ignore();
		cout << " Enter the name of admin: ";				// ----> taking input for credentials
		getline(cin, adm_name);
		cout << " Enter the admin password: ";
		getline(cin, adm_pw);

		for (int i = 0; i < 3; i++)
		{
			if (adm_name == data[i].ad_name && adm_pw == data[i].ad_pw)           // ----> checking for password and user name match
			{
				cout << "\n\n You are successfully logged in ADMIN mode \n\n";
				login = true;
			}
		}
		admin.close();
		return login;															// ----> returning the login value to the function
	}
	bool isLoginTry()
	{
		cout << endl << " Wrong Ussername or Password  Entered!!!!!\n\n" << endl;
		log = false;
		cout << " Do you want to choose another choice ? (y/n)    ";
		cin >> try_top;					// ----> string input for decision
		if (try_top == "y" || try_top == "Y")
		{
			system("cls");
			if (isLogin() == 1)
			{
				log = true;
				system("pause");
				return log;
			}
			else
			{
				isLoginTry();
			}

		}
		else if (try_top == "n" || try_top == "N")
		{
			system("pause");
			exit(0);
		}
		else
		{
			cout << endl << endl << " Wrong choice entered!! The system is exiting due to the wrong format used in admin login. " << endl << endl;
			system("pause");
			exit(0);
		}
		return log;

	}

};
class Person
{
protected:
	int ID;
	char name[30];
	int age;
	char data[30];
	char data1[30];
public:
	void setID(int id)
	{
		ID = id;
	}
	void setName(char *nam)
	{
		char *A;
		A = nam;
		for (int i = 0; i < 30; i++)
		{
			name[i] = A[i];
		}
	}
	void  setAge(int a)
	{
		age = a;
	}
	int retAge()
	{
		return age;
	}
	int retID()
	{
		return ID;
	}
	char * retName()
	{
		return name;
	}
	void setData(char * d)
	{
		char *A;
		A = d;
		for (int i = 0; i < 30; i++)
		{
			data[i] = A[i];
		}
	}

	void setData1(char * d1)
	{
		char *A;
		A = d1;
		for (int i = 0; i < 30; i++)
		{
			data1[i] = A[i];
		}

	}
	char * retData()
	{
		return data;
	}
	char * retData1()
	{
		return data1;
	}
	virtual void add() = 0;
	virtual void del() = 0;
	virtual void show() = 0;
	virtual void up() = 0;
	virtual void search() = 0;

};
class Patient : public Person
{
private:
	char dses[20];
	int rNo;
	int rCh;
	int mCh;
	int days;
	ofstream pat;
	char chk;
	int i;
public:
	void add()
	{
		system("cls");
		pat.open("pat.txt", ios::app);
		Patient info[99];
		i = 0;
		do {
			cout << "Enter ID:";
			cin >> info[i].ID;
			cin.ignore(1);
			cout << "Enter Name:";
			cin.getline(info[i].name, 30);
			cout << "Enter Age:";
			cin >> info[i].age;
			cin.ignore(1);
			cout << "Enter Disease:";
			cin.getline(info[i].dses, 20);
			cout << "Enter Room No. :";
			cin >> info[i].rNo;
			cout << "Enter Room Charges:";
			cin >> info[i].rCh;
			cout << "Enter Medical Charges:";
			cin >> info[i].mCh;
			cout << "Enter Days of stay:";
			cin >> info[i].days;

			pat << endl << info[i].ID << "," << info[i].name << "," << info[i].age << "," << info[i].dses << "," << info[i].rNo << "," << info[i].rCh << "," << info[i].mCh << "," << info[i].days;

			cout << "Do you want to Enter another entery(y/n):";

			cin >> chk;
		} while (chk == 'y' || chk == 'Y');
		pat.close();
		system("pause");
		return;

	}
	void del()
	{
		system("cls");
		cout << " Enter the name of the Patient you want to delete: ";
		Patient info[99];
		ifstream pat;
		ofstream temp;
		pat.open("pat.txt");
		temp.open("temp.txt");
		char data[30];
		int i = 0;
		int q = 0;
		cin.ignore();
		cin.getline(data, 30);
		int x = strlen(data);
		while (!pat.eof())
		{
			pat >> info[i].ID;
			pat.ignore(10, ',');
			pat.getline(info[i].name, 30, ',');
			pat >> info[i].age;
			pat.ignore(10, ',');
			pat.getline(info[i].dses, 20, ',');
			pat >> info[i].rNo;
			pat.ignore(10, ',');
			pat >> info[i].rCh;
			pat.ignore(10, ',');
			pat >> info[i].mCh;
			pat.ignore(10, ',');
			pat >> info[i].days;
			pat.ignore();
			if (strncmp(info[i].name, data, x - 1) == 0)
			{
				i++;
				continue;
			}
			else
			{

				if (q == 1)
				{
					temp << endl << info[i].ID << "," << info[i].name << "," << info[i].age << "," << info[i].dses << "," << info[i].rNo << "," << info[i].rCh << "," << info[i].mCh << "," << info[i].days;
				}
				else
				{
					temp << info[i].ID << "," << info[i].name << "," << info[i].age << "," << info[i].dses << "," << info[i].rNo << "," << info[i].rCh << "," << info[i].mCh << "," << info[i].days;
					q = 1;
				}
			}
			i++;
		}
		temp.close();
		pat.close();
		remove("pat.txt");
		rename("temp.txt", "pat.txt");
		cout << "\nTask completed...\n\n\n";
		system("pause");
		return;
	}
	void show()
	{
		system("cls");
		int i = 0, t = 0;
		ifstream pat;
		pat.open("pat.txt");
		Patient info[99];
		cout << endl << endl << "\t\t\t\t\t\t Patient's Record" << endl << endl;
		cout << endl << endl << right << setw(4) << "ID \t" << left << setw(30) << "Name" << left << setw(4) << "Age \t" << left << setw(20) << "Disease" << left << setw(10) << "Room No." << left << setw(10) << "Room Ch." << left << setw(15) << "Medical Ch" << left << setw(5) << "Days" << endl << endl;
		while (t<112)
		{
			cout << "_";
			t++;
		}
		cout << endl << endl;
		while (!pat.eof())
		{

			pat >> info[i].ID;
			pat.ignore(10, ',');
			pat.getline(info[i].name, 30, ',');
			pat >> info[i].age;
			pat.ignore(10, ',');
			pat.getline(info[i].dses, 20, ',');
			pat >> info[i].rNo;
			pat.ignore(10, ',');
			pat >> info[i].rCh;
			pat.ignore(10, ',');
			pat >> info[i].mCh;
			pat.ignore(10, ',');
			pat >> info[i].days;
			pat.ignore();
			cout << left << setw(4) << info[i].ID << "\t" << left << setw(30) << info[i].name << left << setw(4) << info[i].age << "\t" << left << setw(20) << info[i].dses << left << setw(10) << info[i].rNo << left << setw(10) << info[i].rCh << left << setw(15) << info[i].mCh << left << setw(5) << info[i].days << endl << endl;
			i++;
		}
		t = 0;
		while (t<112)
		{
			cout << "_";
			t++;
		}
		cout << endl << endl;
		pat.close();
		cout << "\nTask completed...\n\n\n";
		system("pause");
		return;
	}
	void up()
	{
		system("cls");
		cout << " Enter the name of the Patient you want to update: ";
		Patient info[99];
		ifstream pat;
		ofstream temp;
		pat.open("pat.txt");
		temp.open("temp.txt");
		char data[30];
		int i = 0;
		int q = 0, w = 0;
		int a = 0;
		cin.ignore();
		cin.getline(data, 30);
		int x = strlen(data);
		while (!pat.eof())
		{
			pat >> info[i].ID;
			pat.ignore(10, ',');
			pat.getline(info[i].name, 30, ',');
			pat >> info[i].age;
			pat.ignore(10, ',');
			pat.getline(info[i].dses, 20, ',');
			pat >> info[i].rNo;
			pat.ignore(10, ',');
			pat >> info[i].rCh;
			pat.ignore(10, ',');
			pat >> info[i].mCh;
			pat.ignore(10, ',');
			pat >> info[i].days;
			pat.ignore();
			if (strncmp(info[i].name, data, x - 1) == 0)
			{
				cout << "Enter NEW ID:";
				cin >> info[i].ID;
				cout << "Enter NEW Age:";
				cin >> info[i].age;
				cin.ignore(1);
				cout << "Enter NEW Dieseas:";
				cin.getline(info[i].dses, 20);
				cout << "Enter NEW Room No. :";
				cin >> info[i].rNo;
				cout << "Enter NEW Room Charges:";
				cin >> info[i].rCh;
				cout << "Enter NEW Medical Charges:";
				cin >> info[i].mCh;
				cout << "Enter NEW Days of stay:";
				cin >> info[i].days;

				if (w == 1 || q == 1)
				{
					temp << endl << info[i].ID << "," << info[i].name << "," << info[i].age << "," << info[i].dses << "," << info[i].rNo << "," << info[i].rCh << "," << info[i].mCh << "," << info[i].days;
				}
				else
				{
					temp << info[i].ID << "," << info[i].name << "," << info[i].age << "," << info[i].dses << "," << info[i].rNo << "," << info[i].rCh << "," << info[i].mCh << "," << info[i].days;
					w = 1;
				}
				i++;
				a = 1;
				continue;
			}
			else
			{

				if (w == 1 || q == 1)
				{
					temp << endl << info[i].ID << "," << info[i].name << "," << info[i].age << "," << info[i].dses << "," << info[i].rNo << "," << info[i].rCh << "," << info[i].mCh << "," << info[i].days;
				}
				else
				{
					temp << info[i].ID << "," << info[i].name << "," << info[i].age << "," << info[i].dses << "," << info[i].rNo << "," << info[i].rCh << "," << info[i].mCh << "," << info[i].days;
					q = 1;
				}
			}
			i++;
		}
		if (a != 1)
		{
			cout << "\n\nNot found\n\n";
		}


		temp.close();
		pat.close();
		remove("pat.txt");
		rename("temp.txt", "pat.txt");
		cout << "\nTask completed...\n\n\n";
		system("pause");
		return;
	}
	void search()
	{
		system("cls");
		cout << " Enter the name of the Patient you want to search: ";
		Patient info[99];
		ifstream pat;
		ofstream temp;
		pat.open("pat.txt");
		temp.open("temp.txt");
		char data[30];
		int i = 0;
		int a = 0;
		int t = 0;
		cin.ignore();
		cin.getline(data, 30);
		int x = strlen(data);
		while (!pat.eof())
		{
			pat >> info[i].ID;
			pat.ignore(10, ',');
			pat.getline(info[i].name, 30, ',');
			pat >> info[i].age;
			pat.ignore(10, ',');
			pat.getline(info[i].dses, 20, ',');
			pat >> info[i].rNo;
			pat.ignore(10, ',');
			pat >> info[i].rCh;
			pat.ignore(10, ',');
			pat >> info[i].mCh;
			pat.ignore(10, ',');
			pat >> info[i].days;
			pat.ignore();
			if (strncmp(info[i].name, data, x - 1) == 0)
			{
				a = 1;
				cout << endl << endl << right << setw(4) << "ID \t" << left << setw(30) << "Name" << left << setw(4) << "Age \t" << left << setw(20) << "Disease" << left << setw(10) << "Room No." << left << setw(10) << "Room Ch." << left << setw(15) << "Medical Ch" << left << setw(5) << "Days" << endl << endl;
				while (t<112)
				{
					cout << "_";
					t++;
				}
				cout << endl << endl;cout << left << setw(4) << info[i].ID << "\t" << left << setw(30) << info[i].name << left << setw(4) << info[i].age << "\t" << left << setw(20) << info[i].dses << left << setw(10) << info[i].rNo << left << setw(10) << info[i].rCh << left << setw(15) << info[i].mCh << left << setw(5) << info[i].days << endl;
				t = 0;
				while (t<112)
				{
					cout << "_";
					t++;
				}
				cout << endl << endl;
				break;
			}
			i++;
		}
		if (a != 1)
		{
			cout << "\n\n Not found \n\n";
		}

		pat.close();
		system("pause");
		return;
	}
};
class Doctor : public Person
{
protected:
	char qual[20];
	char sp[20];
	int exp;
public:
	void setID(int s)
	{
		ID = s;
	}
	void setName(char a[30])
	{
		name[30] = a[30];
	}
	void setAge(int s)
	{
		age = s;
	}
	void add()
	{
		ofstream doc;
		doc.open("doc.txt", ios::app);
		Doctor info[99];
		int i = 0;
		char chk;
		system("cls");
		do {
			cout << "Enter ID:";
			cin >> info[i].ID;
			cin.ignore(1);
			cout << "Enter Name:";
			cin.getline(info[i].name, 30);
			cout << "Enter Qualification:";
			cin.getline(info[i].qual, 20);
			cout << "Enter Specialization:";
			cin.getline(info[i].sp, 20);
			cout << "Enter Age:";
			cin >> info[i].age;
			cout << "Enter Experience:";
			cin >> info[i].exp;
			doc << endl << info[i].ID << "," << info[i].name << "," << info[i].qual << ',' << info[i].sp << ',' << info[i].age << ',' << info[i].exp;
			cout << "Do you want to Enter another entery(y/n):";
			cin >> chk;
		} while (chk == 'y' || chk == 'Y');
		doc.close();
		system("pause");
		return;
	}
	void del()
	{
		system("cls");
		cout << " Enter the name of the Doctor you want to delete: ";
		Doctor info[99];
		ifstream doc;
		ofstream temp;
		doc.open("doc.txt");
		temp.open("temp.txt");
		char data[30];
		int i = 0;
		int q = 0;
		cin.ignore();
		cin.getline(data, 30);
		int x = strlen(data);
		while (!doc.eof())
		{
			doc >> info[i].ID;
			doc.ignore(10, ',');
			doc.getline(info[i].name, 30, ',');
			doc.getline(info[i].qual, 20, ',');
			doc.getline(info[i].sp, 20, ',');
			doc >> info[i].age;
			doc.ignore(10, ',');
			doc >> info[i].exp;
			doc.ignore();
			if (strncmp(info[i].name, data, x - 1) == 0)
			{
				i++;
				continue;
			}
			else
			{
				if (q == 1)
				{
					temp << endl << info[i].ID << "," << info[i].name << "," << info[i].qual << ',' << info[i].sp << ',' << info[i].age << ',' << info[i].exp;
				}
				else
				{
					temp << info[i].ID << "," << info[i].name << "," << info[i].qual << ',' << info[i].sp << ',' << info[i].age << ',' << info[i].exp;
					q = 1;
				}
			}
			i++;
		}
		temp.close();
		doc.close();
		remove("doc.txt");
		rename("temp.txt", "doc.txt");
		cout << "\nTask completed...\n\n\n";
		system("pause");
		return;
	}
	void show()
	{
		system("cls");
		int i = 0;
		Doctor info[99];
		ifstream doc;
		doc.open("doc.txt");
		cout << endl << endl << "\t\t\t\t\t\t Doctor's Record" << endl << endl;
		cout << endl << endl << left << setw(10) << "ID#" << left << setw(30) << "Name" << left << setw(20) << "Qualification" << left << setw(20) << "Specialization" << left << setw(10) << "Age" << left << setw(15) << "Experience" << endl << endl;
		while (i<112)
		{
			cout << "_";
			i++;
		}
		cout << endl << endl;
		while (!doc.eof())
		{
			doc >> info[i].ID;
			doc.ignore(10, ',');
			doc.getline(info[i].name, 30, ',');
			doc.getline(info[i].qual, 20, ',');
			doc.getline(info[i].sp, 20, ',');
			doc >> info[i].age;
			doc.ignore(10, ',');
			doc >> info[i].exp;
			doc.ignore();
			cout << left << setw(10) << info[i].ID << left << setw(30) << info[i].name << left << setw(20) << info[i].qual << left << setw(20) << info[i].sp << left << setw(10) << info[i].age << left << setw(15) << info[i].exp << endl;
			i++;
		}
		i = 0;
		while (i<112)
		{
			cout << "_";
			i++;
		}
		cout << endl << endl;
		doc.close();
		cout << "\n Task completed...\n\n\n";
		return;
	}
	void up()
	{
		system("cls");
		cout << " Enter the name of the Doctor you want to update: ";
		Doctor info[99];
		ifstream doc;
		ofstream temp;
		doc.open("doc.txt");
		temp.open("temp.txt");
		char data[30];
		int i = 0;
		int q = 0, w = 0;
		int a;
		cin.ignore();
		cin.getline(data, 30);
		int x = strlen(data);
		while (!doc.eof())
		{
			doc >> info[i].ID;
			doc.ignore(10, ',');
			doc.getline(info[i].name, 30, ',');
			doc.getline(info[i].qual, 20, ',');
			doc.getline(info[i].sp, 20, ',');
			doc >> info[i].age;
			doc.ignore(10, ',');
			doc >> info[i].exp;
			doc.ignore();
			if (strncmp(info[i].name, data, x - 1) == 0)
			{

				cout << "Enter New ID:";
				cin >> info[i].ID;
				cin.ignore();
				cout << "Enter New Qualification:";
				cin.getline(info[i].qual, 19);
				cout << "Enter New Specialization:";
				cin.getline(info[i].sp, 19);
				cout << "Enter New Age:";
				cin >> info[i].age;
				cout << "Enter New Experience:";
				cin >> info[i].exp;
				if (w == 1 || q == 1)
				{
					temp << endl << info[i].ID << "," << info[i].name << "," << info[i].qual << ',' << info[i].sp << ',' << info[i].age << ',' << info[i].exp;
				}
				else
				{
					temp << info[i].ID << "," << info[i].name << "," << info[i].qual << ',' << info[i].sp << ',' << info[i].age << ',' << info[i].exp;
					w = 1;
				}


				i++;
				a = 1;
				continue;
			}
			else
			{
				if (w == 1 || q == 1)
				{
					temp << endl << info[i].ID << "," << info[i].name << "," << info[i].qual << ',' << info[i].sp << ',' << info[i].age << ',' << info[i].exp;
				}
				else
				{
					temp << info[i].ID << "," << info[i].name << "," << info[i].qual << ',' << info[i].sp << ',' << info[i].age << ',' << info[i].exp << endl;
					q = 1;
				}
			}
			i++;
		}
		if (a != 1)
		{
			cout << "\n\nNot found\n\n";
		}


		temp.close();
		doc.close();
		remove("doc.txt");
		rename("temp.txt", "doc.txt");
		cout << "\nTask completed...\n\n\n";
		system("pause");
		return;

	}
	void search()

	{
		system("cls");
		cout << " Enter the name of the Doctor you want to search: ";
		Doctor info[99];
		ifstream doc;
		doc.open("doc.txt");
		char data[30];
		int i = 0;
		int t = 0;
		int a;
		cin.ignore();
		cin.getline(data, 30);
		int x = strlen(data);
		while (!doc.eof())
		{
			doc >> info[i].ID;
			doc.ignore(10, ',');
			doc.getline(info[i].name, 30, ',');
			doc.getline(info[i].qual, 20, ',');
			doc.getline(info[i].sp, 20, ',');
			doc >> info[i].age;
			doc.ignore(10, ',');
			doc >> info[i].exp;
			doc.ignore();
			if (strncmp(info[i].name, data, x - 1) == 0)
			{
				a = 1;
				cout << endl << endl << left << setw(10) << "ID#" << left << setw(30) << "Name" << left << setw(20) << "Qualification" << left << setw(20) << "Specialization" << left << setw(10) << "Age" << left << setw(15) << "Experience" << endl << endl;
				while (t<112)
				{
					cout << "_";
					t++;
				}
				cout << endl << endl;
				cout << left << setw(10) << info[i].ID << left << setw(30) << info[i].name << left << setw(20) << info[i].qual << left << setw(20) << info[i].sp << left << setw(10) << info[i].age << left << setw(15) << info[i].exp << endl << endl;
				t = 0;
				while (t<112)
				{
					cout << "_";
					t++;
				}
				cout << endl << endl;
				break;
			}
			i++;
		}
		if (a != 1)
		{
			cout << "\n\n Not found \n\n";
		}

		doc.close();
		system("pause");
		return;
	}
};
class Nurse : public Person
{
protected:
	char qual[20];
	int exp;
public:
	void add()
	{
		ofstream nurse;
		nurse.open("nurse.txt", ios::app);
		Nurse info[99];
		int i = 0;
		char chk;
		system("cls");
		do {
			cout << "Enter ID:";
			cin >> info[i].ID;
			cin.ignore(1);
			cout << "Enter Name:";
			cin.getline(info[i].name, 30);
			cout << "Enter Qualification:";
			cin.getline(info[i].qual, 20);
			cout << "Enter Age:";
			cin >> info[i].age;
			cout << "Enter Experience:";
			cin >> info[i].exp;
			nurse << endl << info[i].ID << "," << info[i].name << "," << info[i].qual << ',' << info[i].age << ',' << info[i].exp;
			cout << "Do you want to Enter another entery(y/n):";
			cin >> chk;
		} while (chk == 'y' || chk == 'Y');
		nurse.close();
		system("pause");
		return;
	}
	void del()
	{
		system("cls");
		cout << " Enter the name of the Nurse you want to delete: ";
		Nurse info[99];
		ifstream nurse;
		ofstream temp;
		nurse.open("nurse.txt");
		temp.open("temp.txt");
		char data[30];
		int i = 0;
		int q = 0;
		cin.ignore();
		cin.getline(data, 30);
		int x = strlen(data);
		while (!nurse.eof())
		{
			nurse >> info[i].ID;
			nurse.ignore(10, ',');
			nurse.getline(info[i].name, 30, ',');
			nurse.getline(info[i].qual, 20, ',');
			nurse >> info[i].age;
			nurse.ignore(10, ',');
			nurse >> info[i].exp;
			nurse.ignore();
			if (strncmp(info[i].name, data, x - 1) == 0)
			{
				i++;
				continue;
			}
			else
			{
				if (q == 1)
				{
					temp << endl << info[i].ID << "," << info[i].name << "," << info[i].qual << ',' << info[i].age << ',' << info[i].exp;
				}
				else
				{
					temp << info[i].ID << "," << info[i].name << "," << info[i].qual << ',' << info[i].age << ',' << info[i].exp;
					q = 1;
				}
			}
			i++;
		}
		temp.close();
		nurse.close();
		remove("nurse.txt");
		rename("temp.txt", "nurse.txt");
		cout << "\nTask completed...\n\n\n";
		system("pause");
		return;
	}
	void show()
	{
		system("cls");
		int i = 0, n = 0;
		Nurse info[99];
		ifstream nurse;
		nurse.open("nurse.txt");
		cout << endl << endl << "\t\t\t\t\t\t Nurse's Record" << endl << endl;
		cout << endl << endl << left << setw(10) << "ID#" << left << setw(30) << "Name" << left << setw(20) << "Qualification" << left << setw(10) << "Age" << left << setw(15) << "Experience" << endl << endl;
		while (n<112)
		{
			cout << "_";
			n++;
		}
		cout << endl << endl;
		while (!nurse.eof())
		{
			nurse >> info[i].ID;
			nurse.ignore(10, ',');
			nurse.getline(info[i].name, 30, ',');
			nurse.getline(info[i].qual, 20, ',');
			nurse >> info[i].age;
			nurse.ignore(10, ',');
			nurse >> info[i].exp;
			nurse.ignore();
			cout << left << setw(10) << info[i].ID << left << setw(30) << info[i].name << left << setw(20) << info[i].qual << left << setw(10) << info[i].age << left << setw(15) << info[i].exp << endl;
			i++;
		}
		n = 0;
		while (n<112)
		{
			cout << "_";
			n++;
		}
		cout << endl << endl;
		nurse.close();
		cout << "\n Task completed...\n\n\n";
		return;
	}
	void up()
	{
		system("cls");
		cout << " Enter the name of the Nurse you want to update: ";
		Nurse info[99];
		ifstream nurse;
		ofstream temp;
		nurse.open("nurse.txt");
		temp.open("temp.txt");
		char data[30];
		int i = 0;
		int q = 0, w = 0;
		int a;
		cin.ignore();
		cin.getline(data, 30);
		int x = strlen(data);
		while (!nurse.eof())
		{
			nurse >> info[i].ID;
			nurse.ignore(10, ',');
			nurse.getline(info[i].name, 30, ',');
			nurse.getline(info[i].qual, 20, ',');
			nurse >> info[i].age;
			nurse.ignore(10, ',');
			nurse >> info[i].exp;
			nurse.ignore();
			if (strncmp(info[i].name, data, x - 1) == 0)
			{

				cout << "Enter New ID:";
				cin >> info[i].ID;
				cin.ignore();
				cout << "Enter New Qualification:";
				cin.getline(info[i].qual, 19);
				cout << "Enter New Age:";
				cin >> info[i].age;
				cout << "Enter New Experience:";
				cin >> info[i].exp;
				if (w == 1 || q == 1)
				{
					temp << endl << info[i].ID << "," << info[i].name << "," << info[i].qual << ',' << info[i].age << ',' << info[i].exp;
				}
				else
				{
					temp << info[i].ID << "," << info[i].name << "," << info[i].qual << ',' << info[i].age << ',' << info[i].exp;
					w = 1;
				}


				i++;
				a = 1;
				continue;
			}
			else
			{
				if (w == 1 || q == 1)
				{
					temp << endl << info[i].ID << "," << info[i].name << "," << info[i].qual << ',' << info[i].age << ',' << info[i].exp;
				}
				else
				{
					temp << info[i].ID << "," << info[i].name << "," << info[i].qual << ',' << info[i].age << ',' << info[i].exp << endl;
					q = 1;
				}
			}
			i++;
		}
		if (a != 1)
		{
			cout << "\n\nNot found\n\n";
		}


		temp.close();
		nurse.close();
		remove("nurse.txt");
		rename("temp.txt", "nurse.txt");
		cout << "\nTask completed...\n\n\n";
		system("pause");
		return;

	}
	void search()

	{
		system("cls");
		cout << " Enter the name of the Nurse you want to search: ";
		Nurse info[99];
		ifstream nurse;
		nurse.open("nurse.txt");
		char data[30];
		int i = 0;
		int t = 0;
		int a;
		cin.ignore();
		cin.getline(data, 30);
		int x = strlen(data);
		while (!nurse.eof())
		{
			nurse >> info[i].ID;
			nurse.ignore(10, ',');
			nurse.getline(info[i].name, 30, ',');
			nurse.getline(info[i].qual, 20, ',');
			nurse >> info[i].age;
			nurse.ignore(10, ',');
			nurse >> info[i].exp;
			nurse.ignore();
			if (strncmp(info[i].name, data, x - 1) == 0)
			{
				a = 1;
				cout << endl << endl << left << setw(10) << "ID#" << left << setw(30) << "Name" << left << setw(20) << "Qualification" << left << setw(10) << "Age" << left << setw(15) << "Experience" << endl << endl;
				while (t<112)
				{
					cout << "_";
					t++;
				}
				cout << endl << endl;
				cout << left << setw(10) << info[i].ID << left << setw(30) << info[i].name << left << setw(20) << info[i].qual << left << setw(10) << info[i].age << left << setw(15) << info[i].exp << endl << endl;
				t = 0;
				while (t<112)
				{
					cout << "_";
					t++;
				}
				cout << endl << endl;
				break;
			}
			i++;
		}
		if (a != 1)
		{
			cout << "\n\n Not found \n\n";
		}

		nurse.close();
		system("pause");
		return;
	}
};
class Menu
{
private:

public:
	void dis()
	{
		system("COLOR 70");
		cout << endl << endl << "        ";
		for (int c = 0; c<30; c++)					// ----> The main heading line
		{
			cout << "*";
		}
		cout << "  _Welcome to The Hospital Management System_  ";
		for (int c = 0; c<30; c++)
		{
			cout << "*";
		}
		cout << endl;
		cout << endl;

		cout << "\t\t\t\t Please Enter the password to gain access to the system : " << endl << endl;
	}
	void dis1()
	{
		cout << "\t\t______________________________________________________\n\n\t\t\t 1. To gain access to admin mode\n\t\t\t 2. To go to the visitor section\n\t\t\t 3. To exit the system \n\t\t______________________________________________________" << endl;
		cout << endl << " Please enter your choice (1-3) :   ";
	}
	void dis2()
	{
		cout << "\t\t______________________________________________________\n\n\t\t\t\t ***Admin Mode*** \n\n\t\t\t 1. To add a patient in hospital database\n\t\t\t 2. To remove a patient in hospital database\n\t\t\t 3. To add a doctor in hospital database\n\t\t\t 4. To remove a doctor in hospital database\n\t\t\t 5. To add a nurse in hospital database\n\t\t\t 6. To del a nurse in hospital database \n\t\t\t 7. To update a patient record\n\t\t\t 8. To update a doctor record\n\t\t\t 9. To update a nurse record\n\t\t\t 10. To assign  patient , a doctor and a nurse\n\t\t\t 11. To go back to the main menu\n\t\t\t 12. To exit the program \n\t\t______________________________________________________\n";

		cout << endl << " Please enter your choice (1-12) :   ";
	}
	void dis3()
	{
		cout << " \t\t__________________________________________________________\n\n\t\t\t\t ***Visitor section*** \n\n\t\t\t 1. To display the list of all doctors in the hospital \n\t\t\t 2. To display the list of all patients	\n\t\t\t 3. To display the list of all nurses in the hospital \n\t\t\t 4. To search a doctor for its availability	\n\t\t\t 5. To search a nurse for its availability\n\t\t\t 6. To search a patient\n\t\t\t 7. To view the list of assigned patients \n\t\t\t 8. To go back to the main menu\n\t\t\t 9. To exit the program \n\t\t__________________________________________________________\n";

		cout << endl << " Please enter your choice (1-9) :   ";
	}
};
class TryPass
{
private:
	string pw;
	int n;
	int a;
public:

	bool trypass()
	{
		n = 0;
		a = 2;
		while (n <= 0)

		{
			cout << "                                              ";
			cin >> pw;									// ----> input password string for login to the library
			if (pw == "p")
			{
				system("cls");
				n = 1;
			}
			else
			{
				cout << "\n\t   You entered the wrong password, please try again by pressing another password. " << a << " tries left.\n\n\n";
				n--;
				a--;
			}
			if (n == -3)
			{
				cout << "\n\t\t\t   You tried many times.The system is exiting. " << endl << endl;
				return false;

			}
		}
	}
};
class Assign : public Doctor
{
private:
	Doctor d;
	Nurse nu;
	char choice;
	Person *info[99];
	char namex[30];
	char namex1[30];
	//char data[30];
	//char data1[30];
	int i, q, w, a, b, x, t;
public:
	void doAssign()
	{
		Person *doct, *nrse;
		doct = &d;
		nrse = &nu;
		system("cls");
		cout << " Do you want to see the list of doctors and nurses available ? (y/n) ";
		cin >> choice;
		if (choice == 'y' || choice == 'Y')
		{
			doct->show();
			system("pause");
			nrse->show();
			system("pause");
		}
		cout << "\nEnter the name of the doctor you want to assign: ";
		ifstream doc;
		ifstream nur;
		ofstream temp;
		ofstream temp1;
		ofstream assign;
		doc.open("doc.txt");
		assign.open("assigned_doc.txt", ios::app);										// ----> Opening the file for writing in append mode
		temp.open("temp.txt");															// ----> Opening the file for writing
		cin.ignore();
		cin.getline(data, 30);
		x = strlen(data);
		q = 0;
		w = 0;
		while (!doc.eof())
		{
			doc >> ID;
			d.setID(ID);
			doc.ignore(10, ',');
			doc.getline(name, 30, ',');
			d.setName(name);
			doc.getline(qual, 20, ',');
			doc.getline(sp, 20, ',');
			doc >> age;
			d.setAge(age);
			doc.ignore(10, ',');
			doc >> exp;
			doc.ignore();
			if (strncmp(name, data, x - 1) == 0)
			{

				cout << "Enter Patient ID:";
				cin >> ID;
				cin.ignore(1);
				cout << "Enter Patient Name:";
				cin.getline(namex, 30);
				cout << "Enter Patient Age:";
				cin >> age;
				cin.ignore(1);
				assign << endl << ID << "," << namex << "," << age << ',' << data;
				a = 1;
				continue;
			}
			else
			{
				if (q == 1)
				{
					temp << endl << ID << "," << name << "," << qual << ',' << sp << ',' << age << ',' << exp;
				}
				else
				{
					temp << ID << "," << name << "," << qual << ',' << sp << ',' << age << ',' << exp;
					q = 1;
				}
			}
		}
		if (a != 1)
		{
			cout << "\n\nDoctor Not found,going back\n\n";
			goto xyz;
		}
		cout << "\nEnter the name of the nurse you want to assign: ";
		cin.getline(data, 30);
		x = strlen(data);
		temp1.open("temp1.txt");
		nur.open("nurse.txt");
		w = 0;
		b = 0;
		while (!nur.eof())
		{
			nur >> ID;
			nur.ignore(10, ',');
			nur.getline(name, 30, ',');
			nur.getline(qual, 20, ',');
			nur >> age;
			nur.ignore(10, ',');
			nur >> exp;
			nur.ignore();
			if (strncmp(name, data, x - 1) == 0)
			{
				assign << "," << data;
				b = 1;
				continue;
			}
			else
			{
				if (w == 1)
				{
					temp1 << endl << ID << "," << name << "," << qual << ',' << age << ',' << exp;
				}
				else
				{
					temp1 << ID << "," << name << "," << qual << ',' << age << ',' << exp;
					w = 1;
				}
			}


		}

		if (b != 1)
		{

			assign << ", NOt Found";

			cout << "\n\nNurse Not found\n\n";
		}
		nur.close();
		temp1.close();
		remove("nurse.txt");
		rename("temp1.txt", "nurse.txt");

	xyz:
		doc.close();
		temp.close();
		assign.close();
		remove("doc.txt");
		rename("temp.txt", "doc.txt");
		cout << "\nTask completed...\n\n\n";
		system("pause");
		return;
	}

	void showAssign()
	{
		system("cls");
		i = 0;
		t = 0;
		ifstream as;
		as.open("assigned_doc.txt");
		cout << right << setw(10) << "Patient ID \t" << left << setw(30) << "Patient Name" << left << setw(10) << "Patient Age \t" << left << setw(20) << "Doctor Name" << left << setw(20) << "Nurse Name" << endl << endl;
		while (i<92)
		{
			cout << "_";
			i++;
		}
		as.ignore(INT_MAX, '\n');
		cout << endl << endl;
		int age1,id1;
		while (!as.eof())
		{
			as >> id1;
			this->setID(id1);
			as.ignore(10, ',');
			as.getline(name, 30, ',');
			this->setName(name);
			as >> age1;
			this->setAge(age1);
			as.ignore(10, ',');
			as.getline(data, 30, ',');
			this->setData(data);
			as.getline(data1, 30, '\n');
			this->setData1(data1);
			cout << left << setw(10) << this->retID() << "\t" << left << setw(30) << this->retName() << left << setw(10) << this->retAge() << "\t" << left << setw(20) << this->retData() << left << setw(20) << this->retData1() << endl;
			t++;
		}
		i = 0;
		while (i<92)
		{
			cout << "_";
			i++;
		}
		cout << endl << endl;
		as.close();
		//delete info;
		cout << "\nTask completed...\n\n\n";
		system("pause");
		return;
	}

};
int main()
{
	string n;
	Menu a;
	TryPass t;
	Admin d;
	Person *patient, *doctor, *nrse;
	Patient p;
	Doctor doc;
	Nurse nu;
	Assign s;
	patient = &p;
	doctor = &doc;
	nrse = &nu;
	a.dis();
	if (t.trypass() == 0)
	{
		goto exit;
	}
top1:							// ----> defining label for first screen
	a.dis1();

	cin >> n;
	if (n == "1")
	{	//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		// ADMIN MODE
		if (d.isLogin() == 1)
		{
		top2:
			system("cls");
			a.dis2();
			cin >> n;
			if (n == "1")
			{
				patient->add();
				goto top2;
			}
			if (n == "2")
			{
				patient->del();
				goto top2;
			}
			if (n == "3")
			{
				doctor->add();
				goto top2;
			}
			if (n == "4")
			{
				doctor->del();
				goto top2;
			}
			if (n == "5")
			{
				nrse->add();
				goto top2;
			}
			if (n == "6")
			{
				nrse->del();
				goto top2;
			}
			if (n == "7")
			{
				patient->up();
				goto top2;
			}
			if (n == "8")
			{
				doctor->up();
				goto top2;
			}
			if (n == "9")
			{
				nrse->up();
				goto top2;
			}
			if (n == "10")
			{
				s.doAssign();
				goto top2;
			}
			if (n == "11")
			{
				system("cls");
				goto top1;
			}
			if (n == "12")
			{
				goto exit;
			}
			else
			{
				cout << "\n Invalid Entry. Please try again. \n\n";
				system("pause");
				goto top2;
			}
		}
		else
		{
			if (d.isLoginTry() == 1)
			{
				goto top2;
			}
		}
	}
	//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	// VISITOR SECTION
	if (n == "2")
	{
	top3:

		system("cls");
		a.dis3();
		cin >> n;
		if (n == "1")
		{
			doctor->show();
			system("pause");
			goto top3;
		}
		if (n == "2")
		{
			patient->show();
			goto top3;
		}
		if (n == "3")
		{
			nrse->show();
			system("pause");
			goto top3;
		}
		if (n == "4")
		{
			doctor->search();
			goto top3;
		}

		if (n == "5")
		{
			nrse->search();
			goto top3;
		}
		if (n == "6")
		{
			patient->search();
			goto top3;
		}
		if (n == "7")
		{
			s.showAssign();
			system("pause");
			goto top3;
		}
		if (n == "8")
		{
			system("cls");
			goto top1;
		}
		if (n == "9")
		{
			goto exit;
		}
		else
		{
			cout << "\n Invalid Entry. Please try again. \n\n";
			system("pause");
			goto top2;
		}

	}
	if (n == "3")
	{
		goto exit;
	}
	else
	{
		cout << "\n Invalid Entry. Please try again. \n\n";
		system("pause");
		system("cls");
		goto top1;
	}

exit:
	system("pause");
}
